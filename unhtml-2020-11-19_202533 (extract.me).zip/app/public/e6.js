const E6API = require("e6api");
const e6 = new E6API({
  userAgent: "E6API/1.0.6 (https://github.com/FurryBotCo/E6API)"
});
async function e621Get(){
    alert("hey guys");
  e6.listPosts(["pikachu","order:random"], 1, 1, null, []).then(posts=>console.log(posts[0].file.url))
  alert("hOi!")
}
async function func(){
    alert('Hello World!');
  console.log("hOi!");
  let e="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
  console.log("Hello world");
  document.getElementById("e6img").src = e;
}